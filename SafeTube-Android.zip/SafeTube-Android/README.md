# SafeTube — Parent-Approved YouTube Android App

SafeTube is a YouTube-like Android application with a single strict filter (`ParentApprovalFilter`) that allows **only parent-approved channels and parent-approved videos**.

## Features
- **Home, Channels, Watch Later & History tabs** — all strictly filtered by `ParentApprovalFilter`.
- **Search within approved content** — filters titles and channels locally.
- **Locked-down Fullscreen Video Player** — plays via `youtube-nocookie.com/embed/...` and blocks navigation to unapproved videos or channels.
- **PIN-Protected Parent Dashboard** (default PIN: `1234`) — add/remove approved channels (`UC...` IDs or `/channel/UC...` URLs), add/remove individual videos, and change PIN.

## Build the APK Without a PC (GitHub Actions on Your Phone)
1. Unzip `SafeTube-Android.zip` on your phone.
2. Create a free repository on GitHub and upload the contents of `SafeTube-Android` (including the `.github` folder).
3. Open the **Actions** tab in your GitHub repository and run **Build SafeTube APK**.
4. Download the `SafeTube-debug-apk` artifact and install `app-debug.apk` on your Android phone.
