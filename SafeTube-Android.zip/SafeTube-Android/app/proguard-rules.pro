# SafeTube ProGuard rules
