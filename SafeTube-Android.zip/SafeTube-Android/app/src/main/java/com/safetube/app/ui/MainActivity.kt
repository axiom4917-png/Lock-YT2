package com.safetube.app.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.safetube.app.R
import com.safetube.app.data.ApprovalStore
import com.safetube.app.data.YouTubeFeedFetcher
import com.safetube.app.databinding.ActivityMainBinding
import com.safetube.app.databinding.DialogPinBinding
import com.safetube.app.filter.ParentApprovalFilter
import com.safetube.app.model.FeedVideo
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var store: ApprovalStore
    private lateinit var adapter: VideoAdapter
    private val executor = Executors.newSingleThreadExecutor()
    private var allFetchedVideos: List<FeedVideo> = emptyList()
    private var selectedChannelId: String? = null
    private var currentTab: Tab = Tab.HOME

    enum class Tab { HOME, CHANNELS, WATCH_LATER, HISTORY }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        store = ApprovalStore(this)
        adapter = VideoAdapter(
            onVideoClick = { video -> openApprovedPlayer(video) },
            onWatchLaterToggle = { video ->
                val added = store.toggleWatchLater(video.videoId)
                Toast.makeText(
                    this,
                    if (added) getString(R.string.added_watch_later) else getString(R.string.removed_watch_later),
                    Toast.LENGTH_SHORT
                ).show()
                applyFilterAndRender()
            }
        )

        binding.rvVideos.layoutManager = LinearLayoutManager(this)
        binding.rvVideos.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { loadApprovedFeed() }
        binding.btnParentMode.setOnClickListener { promptParentPin() }

        binding.bottomNav.setOnItemSelectedListener { item ->
            currentTab = when (item.itemId) {
                R.id.nav_home -> Tab.HOME
                R.id.nav_channels -> Tab.CHANNELS
                R.id.nav_watch_later -> Tab.WATCH_LATER
                R.id.nav_history -> Tab.HISTORY
                else -> Tab.HOME
            }
            binding.channelChipScroll.visibility =
                if (currentTab == Tab.CHANNELS) View.VISIBLE else View.GONE
            if (currentTab != Tab.CHANNELS) {
                selectedChannelId = null
            }
            applyFilterAndRender()
            true
        }

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                applyFilterAndRender()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun onResume() {
        super.onResume()
        renderChannelChips()
        loadApprovedFeed()
    }

    private fun renderChannelChips() {
        val group = binding.channelChipGroup
        group.removeAllViews()

        val allChip = Chip(this).apply {
            text = getString(R.string.all_approved_channels)
            isCheckable = true
            isChecked = selectedChannelId == null
            setOnClickListener {
                selectedChannelId = null
                applyFilterAndRender()
            }
        }
        group.addView(allChip)

        store.getApprovedChannels().forEach { channel ->
            val chip = Chip(this).apply {
                text = channel.name
                isCheckable = true
                isChecked = selectedChannelId == channel.channelId
                setOnClickListener {
                    selectedChannelId = channel.channelId
                    applyFilterAndRender()
                }
            }
            group.addView(chip)
        }
    }

    private fun loadApprovedFeed() {
        binding.swipeRefresh.isRefreshing = true
        val channels = store.getApprovedChannels()
        val videos = store.getApprovedVideos()

        executor.execute {
            val fetched = YouTubeFeedFetcher.fetchApprovedFeed(channels, videos)
            runOnUiThread {
                allFetchedVideos = fetched
                binding.swipeRefresh.isRefreshing = false
                applyFilterAndRender()
            }
        }
    }

    private fun applyFilterAndRender() {
        val channels = store.getApprovedChannels()
        val approvedVideos = store.getApprovedVideos()
        val watchLaterIds = store.getWatchLaterIds()
        val query = binding.etSearch.text?.toString().orEmpty()

        val baseList = when (currentTab) {
            Tab.HOME -> allFetchedVideos
            Tab.CHANNELS -> allFetchedVideos
            Tab.WATCH_LATER -> allFetchedVideos.filter { watchLaterIds.contains(it.videoId) }
            Tab.HISTORY -> store.getHistory()
        }

        val filtered = ParentApprovalFilter.filterFeed(
            candidates = baseList,
            approvedChannels = channels,
            approvedVideos = approvedVideos,
            searchQuery = query,
            selectedChannelId = if (currentTab == Tab.CHANNELS) selectedChannelId else null
        )

        adapter.submitList(filtered, watchLaterIds)
        binding.tvEmpty.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openApprovedPlayer(video: FeedVideo) {
        val allowed = ParentApprovalFilter.isVideoAllowed(
            videoId = video.videoId,
            channelId = video.channelId,
            approvedChannels = store.getApprovedChannels(),
            approvedVideos = store.getApprovedVideos()
        )
        if (!allowed) {
            Toast.makeText(this, getString(R.string.blocked_video_msg), Toast.LENGTH_SHORT).show()
            return
        }
        store.recordHistory(video)
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_VIDEO_ID, video.videoId)
            putExtra(PlayerActivity.EXTRA_CHANNEL_ID, video.channelId)
            putExtra(PlayerActivity.EXTRA_TITLE, video.title)
            putExtra(PlayerActivity.EXTRA_CHANNEL_NAME, video.channelName)
        }
        startActivity(intent)
    }

    private fun promptParentPin() {
        val dialogBinding = DialogPinBinding.inflate(layoutInflater)
        AlertDialog.Builder(this)
            .setTitle(R.string.enter_parent_pin)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.unlock) { _, _ ->
                val entered = dialogBinding.etPin.text?.toString().orEmpty()
                if (store.verifyPin(entered)) {
                    startActivity(Intent(this, ParentDashboardActivity::class.java))
                } else {
                    Toast.makeText(this, R.string.invalid_pin, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
