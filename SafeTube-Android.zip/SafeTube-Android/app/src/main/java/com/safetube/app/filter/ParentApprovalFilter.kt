package com.safetube.app.filter

import com.safetube.app.model.ApprovedChannel
import com.safetube.app.model.ApprovedVideo
import com.safetube.app.model.FeedVideo

/**
 * Single authoritative filter enforcing that ONLY videos from parent-approved
 * channels or explicitly parent-approved videos are visible and playable across
 * Home, Subscriptions, Search, Watch Later, History, and Player.
 */
object ParentApprovalFilter {

    fun isVideoAllowed(
        videoId: String,
        channelId: String?,
        approvedChannels: List<ApprovedChannel>,
        approvedVideos: List<ApprovedVideo>
    ): Boolean {
        val cleanVideoId = videoId.trim()
        if (cleanVideoId.isEmpty()) return false

        if (approvedVideos.any { it.videoId == cleanVideoId }) {
            return true
        }

        val cleanChannelId = channelId?.trim().orEmpty()
        if (cleanChannelId.isEmpty()) return false

        return approvedChannels.any { it.channelId == cleanChannelId }
    }

    fun filterFeed(
        candidates: List<FeedVideo>,
        approvedChannels: List<ApprovedChannel>,
        approvedVideos: List<ApprovedVideo>,
        searchQuery: String = "",
        selectedChannelId: String? = null
    ): List<FeedVideo> {
        val query = searchQuery.trim().lowercase()
        return candidates
            .filter { video ->
                isVideoAllowed(
                    videoId = video.videoId,
                    channelId = video.channelId,
                    approvedChannels = approvedChannels,
                    approvedVideos = approvedVideos
                )
            }
            .filter { video ->
                selectedChannelId.isNullOrBlank() || video.channelId == selectedChannelId
            }
            .distinctBy { it.videoId }
            .filter { video ->
                if (query.isEmpty()) {
                    true
                } else {
                    video.title.lowercase().contains(query) ||
                        video.channelName.lowercase().contains(query)
                }
            }
    }
}
