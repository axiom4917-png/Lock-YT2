package com.safetube.app.model

data class ApprovedChannel(
    val channelId: String,
    val name: String
)

data class ApprovedVideo(
    val videoId: String,
    val title: String,
    val channelName: String,
    val channelId: String = ""
)

data class FeedVideo(
    val videoId: String,
    val title: String,
    val channelId: String,
    val channelName: String,
    val thumbnailUrl: String,
    val publishedAt: String = "",
    val isStandaloneApproved: Boolean = false
)
