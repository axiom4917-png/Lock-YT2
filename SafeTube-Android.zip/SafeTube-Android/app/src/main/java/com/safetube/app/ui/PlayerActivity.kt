package com.safetube.app.ui

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.safetube.app.R
import com.safetube.app.data.ApprovalStore
import com.safetube.app.databinding.ActivityPlayerBinding
import com.safetube.app.filter.ParentApprovalFilter

class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private var isFullscreen = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val videoId = intent.getStringExtra(EXTRA_VIDEO_ID).orEmpty()
        val channelId = intent.getStringExtra(EXTRA_CHANNEL_ID).orEmpty()
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val channelName = intent.getStringExtra(EXTRA_CHANNEL_NAME).orEmpty()

        val store = ApprovalStore(this)
        val isAllowed = ParentApprovalFilter.isVideoAllowed(
            videoId = videoId,
            channelId = channelId,
            approvedChannels = store.getApprovedChannels(),
            approvedVideos = store.getApprovedVideos()
        )

        if (!isAllowed) {
            Toast.makeText(this, R.string.blocked_video_msg, Toast.LENGTH_LONG).show()
            finish()
            return
        }

        binding.tvVideoTitle.text = title
        binding.tvChannelName.text = channelName
        binding.btnBack.setOnClickListener { finish() }
        binding.btnFullscreen.setOnClickListener { toggleFullscreen() }

        binding.webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        binding.webView.webChromeClient = WebChromeClient()

        binding.webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString().orEmpty()
                val allowedEmbedPrefix = "https://www.youtube-nocookie.com/embed/$videoId"
                if (url.startsWith(allowedEmbedPrefix)) {
                    return false
                }
                Toast.makeText(
                    this@PlayerActivity,
                    getString(R.string.navigation_blocked_msg),
                    Toast.LENGTH_SHORT
                ).show()
                return true
            }
        }

        val embedHtml = """
            <!DOCTYPE html>
            <html>
            <head>
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <style>
                html, body { margin: 0; padding: 0; background: #000; height: 100%; width: 100%; overflow: hidden; }
                iframe { border: 0; width: 100%; height: 100%; }
              </style>
            </head>
            <body>
              <iframe
                src="https://www.youtube-nocookie.com/embed/$videoId?rel=0&modestbranding=1&playsinline=1"
                allow="autoplay; encrypted-media; picture-in-picture"
                allowfullscreen>
              </iframe>
            </body>
            </html>
        """.trimIndent()

        binding.webView.loadDataWithBaseURL(
            "https://www.youtube-nocookie.com",
            embedHtml,
            "text/html",
            "UTF-8",
            null
        )
    }

    private fun toggleFullscreen() {
        isFullscreen = !isFullscreen
        if (isFullscreen) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            binding.detailsContainer.visibility = View.GONE
            binding.webView.layoutParams.height = android.view.ViewGroup.LayoutParams.MATCH_PARENT
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            binding.detailsContainer.visibility = View.VISIBLE
            val heightPx = (240 * resources.displayMetrics.density).toInt()
            binding.webView.layoutParams.height = heightPx
        }
        binding.webView.requestLayout()
    }

    override fun onDestroy() {
        binding.webView.destroy()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_VIDEO_ID = "extra_video_id"
        const val EXTRA_CHANNEL_ID = "extra_channel_id"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_CHANNEL_NAME = "extra_channel_name"
    }
}
