package com.safetube.app.data

import android.net.Uri
import android.util.Xml
import com.safetube.app.model.ApprovedChannel
import com.safetube.app.model.ApprovedVideo
import com.safetube.app.model.FeedVideo
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

object YouTubeFeedFetcher {

    fun extractVideoId(input: String): String? {
        val trimmed = input.trim()
        if (Regex("^[a-zA-Z0-9_-]{11}$").matches(trimmed)) {
            return trimmed
        }
        return try {
            val uri = Uri.parse(trimmed)
            val host = uri.host?.lowercase().orEmpty()
            when {
                host.contains("youtu.be") -> uri.lastPathSegment?.take(11)
                host.contains("youtube.com") -> {
                    uri.getQueryParameter("v")?.take(11)
                        ?: run {
                            val segments = uri.pathSegments
                            val embedIdx = segments.indexOf("embed")
                            val shortsIdx = segments.indexOf("shorts")
                            when {
                                embedIdx >= 0 && embedIdx + 1 < segments.size -> segments[embedIdx + 1].take(11)
                                shortsIdx >= 0 && shortsIdx + 1 < segments.size -> segments[shortsIdx + 1].take(11)
                                else -> null
                            }
                        }
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    fun extractChannelId(input: String): String? {
        val trimmed = input.trim()
        if (Regex("^UC[a-zA-Z0-9_-]{22}$").matches(trimmed)) {
            return trimmed
        }
        return try {
            val uri = Uri.parse(trimmed)
            val queryId = uri.getQueryParameter("channel_id")
            if (!queryId.isNullOrBlank() && queryId.startsWith("UC")) {
                return queryId
            }
            val segments = uri.pathSegments
            val idx = segments.indexOf("channel")
            if (idx >= 0 && idx + 1 < segments.size) {
                val candidate = segments[idx + 1]
                if (candidate.startsWith("UC")) return candidate
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    fun fetchApprovedFeed(
        channels: List<ApprovedChannel>,
        standaloneVideos: List<ApprovedVideo>
    ): List<FeedVideo> {
        val results = mutableListOf<FeedVideo>()

        standaloneVideos.forEach { v ->
            results.add(
                FeedVideo(
                    videoId = v.videoId,
                    title = v.title,
                    channelId = v.channelId,
                    channelName = v.channelName,
                    thumbnailUrl = "https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg",
                    publishedAt = "Parent Approved",
                    isStandaloneApproved = true
                )
            )
        }

        channels.forEach { channel ->
            runCatching {
                val rssUrl = "https://www.youtube.com/feeds/videos.xml?channel_id=${channel.channelId}"
                val conn = (URL(rssUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                    conn.inputStream.use { stream ->
                        results.addAll(parseRssFeed(stream, channel))
                    }
                }
                conn.disconnect()
            }
        }

        return results
    }

    private fun parseRssFeed(inputStream: InputStream, channel: ApprovedChannel): List<FeedVideo> {
        val videos = mutableListOf<FeedVideo>()
        val parser = Xml.newPullParser().apply {
            setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            setInput(inputStream, null)
        }

        var inEntry = false
        var videoId = ""
        var title = ""
        var published = ""
        var currentTag = ""

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    currentTag = parser.name
                    if (currentTag == "entry") {
                        inEntry = true
                        videoId = ""
                        title = ""
                        published = ""
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inEntry) {
                        val text = parser.text?.trim().orEmpty()
                        when (currentTag) {
                            "yt:videoId" -> videoId = text
                            "title" -> if (title.isEmpty()) title = text
                            "published" -> published = text.take(10)
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "entry" && inEntry) {
                        if (videoId.isNotEmpty() && title.isNotEmpty()) {
                            videos.add(
                                FeedVideo(
                                    videoId = videoId,
                                    title = title,
                                    channelId = channel.channelId,
                                    channelName = channel.name,
                                    thumbnailUrl = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg",
                                    publishedAt = published,
                                    isStandaloneApproved = false
                                )
                            )
                        }
                        inEntry = false
                    }
                    currentTag = ""
                }
            }
            eventType = parser.next()
        }
        return videos
    }
}
