package com.safetube.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.safetube.app.R
import com.safetube.app.databinding.ItemVideoCardBinding
import com.safetube.app.model.FeedVideo

class VideoAdapter(
    private val onVideoClick: (FeedVideo) -> Unit,
    private val onWatchLaterToggle: (FeedVideo) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VideoViewHolder>() {

    private val items = mutableListOf<FeedVideo>()
    private var watchLaterIds: Set<String> = emptySet()

    fun submitList(videos: List<FeedVideo>, savedIds: Set<String>) {
        items.clear()
        items.addAll(videos)
        watchLaterIds = savedIds
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoViewHolder {
        val binding = ItemVideoCardBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return VideoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: VideoViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class VideoViewHolder(
        private val binding: ItemVideoCardBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(video: FeedVideo) {
            binding.tvTitle.text = video.title
            binding.tvChannel.text = if (video.publishedAt.isNotEmpty()) {
                "${video.channelName} • ${video.publishedAt}"
            } else {
                video.channelName
            }
            binding.tvBadge.text = if (video.isStandaloneApproved) {
                "Approved Video"
            } else {
                "Approved Channel"
            }
            val isSaved = watchLaterIds.contains(video.videoId)
            binding.btnWatchLater.text = if (isSaved) {
                binding.root.context.getString(R.string.saved_label)
            } else {
                binding.root.context.getString(R.string.save_label)
            }
            binding.btnWatchLater.setOnClickListener { onWatchLaterToggle(video) }
            ThumbnailLoader.load(binding.ivThumbnail, video.thumbnailUrl)
            binding.root.setOnClickListener { onVideoClick(video) }
        }
    }
}
