package com.safetube.app.data

import android.content.Context
import android.content.SharedPreferences
import com.safetube.app.model.ApprovedChannel
import com.safetube.app.model.ApprovedVideo
import com.safetube.app.model.FeedVideo
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

class ApprovalStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("safetube_parent_store", Context.MODE_PRIVATE)

    init {
        if (!prefs.contains(KEY_INITIALIZED)) {
            seedDefaults()
        }
    }

    private fun seedDefaults() {
        val starterChannels = listOf(
            ApprovedChannel("UCX6b17PVsYBQ0ip5gyeme-Q", "CrashCourse"),
            ApprovedChannel("UCsooa4yRKGN_zEE8iknghZA", "TED-Ed")
        )
        saveChannels(starterChannels)
        saveVideos(emptyList())
        setPin("1234")
        prefs.edit().putBoolean(KEY_INITIALIZED, true).apply()
    }

    fun getApprovedChannels(): List<ApprovedChannel> {
        val arr = JSONArray(prefs.getString(KEY_CHANNELS, "[]") ?: "[]")
        val list = mutableListOf<ApprovedChannel>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(ApprovedChannel(obj.getString("channelId"), obj.getString("name")))
        }
        return list
    }

    fun addChannel(channel: ApprovedChannel) {
        val current = getApprovedChannels().toMutableList()
        if (current.none { it.channelId == channel.channelId }) {
            current.add(channel)
            saveChannels(current)
        }
    }

    fun removeChannel(channelId: String) {
        saveChannels(getApprovedChannels().filterNot { it.channelId == channelId })
    }

    private fun saveChannels(channels: List<ApprovedChannel>) {
        val arr = JSONArray()
        channels.forEach {
            arr.put(JSONObject().apply {
                put("channelId", it.channelId)
                put("name", it.name)
            })
        }
        prefs.edit().putString(KEY_CHANNELS, arr.toString()).apply()
    }

    fun getApprovedVideos(): List<ApprovedVideo> {
        val arr = JSONArray(prefs.getString(KEY_VIDEOS, "[]") ?: "[]")
        val list = mutableListOf<ApprovedVideo>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                ApprovedVideo(
                    videoId = obj.getString("videoId"),
                    title = obj.getString("title"),
                    channelName = obj.optString("channelName", "Approved Video"),
                    channelId = obj.optString("channelId", "")
                )
            )
        }
        return list
    }

    fun addVideo(video: ApprovedVideo) {
        val current = getApprovedVideos().toMutableList()
        if (current.none { it.videoId == video.videoId }) {
            current.add(video)
            saveVideos(current)
        }
    }

    fun removeVideo(videoId: String) {
        saveVideos(getApprovedVideos().filterNot { it.videoId == videoId })
    }

    private fun saveVideos(videos: List<ApprovedVideo>) {
        val arr = JSONArray()
        videos.forEach {
            arr.put(JSONObject().apply {
                put("videoId", it.videoId)
                put("title", it.title)
                put("channelName", it.channelName)
                put("channelId", it.channelId)
            })
        }
        prefs.edit().putString(KEY_VIDEOS, arr.toString()).apply()
    }

    // Watch Later
    fun getWatchLaterIds(): Set<String> {
        val arr = JSONArray(prefs.getString(KEY_WATCH_LATER, "[]") ?: "[]")
        val set = linkedSetOf<String>()
        for (i in 0 until arr.length()) set.add(arr.getString(i))
        return set
    }

    fun toggleWatchLater(videoId: String): Boolean {
        val current = getWatchLaterIds().toMutableSet()
        val added = if (current.contains(videoId)) {
            current.remove(videoId)
            false
        } else {
            current.add(videoId)
            true
        }
        val arr = JSONArray()
        current.forEach { arr.put(it) }
        prefs.edit().putString(KEY_WATCH_LATER, arr.toString()).apply()
        return added
    }

    // Watch History (most recent first, max 50)
    fun recordHistory(video: FeedVideo) {
        val current = getHistory().filterNot { it.videoId == video.videoId }.toMutableList()
        current.add(0, video)
        val trimmed = current.take(50)
        val arr = JSONArray()
        trimmed.forEach {
            arr.put(JSONObject().apply {
                put("videoId", it.videoId)
                put("title", it.title)
                put("channelId", it.channelId)
                put("channelName", it.channelName)
                put("thumbnailUrl", it.thumbnailUrl)
                put("publishedAt", it.publishedAt)
                put("isStandaloneApproved", it.isStandaloneApproved)
            })
        }
        prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
    }

    fun getHistory(): List<FeedVideo> {
        val arr = JSONArray(prefs.getString(KEY_HISTORY, "[]") ?: "[]")
        val list = mutableListOf<FeedVideo>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                FeedVideo(
                    videoId = obj.getString("videoId"),
                    title = obj.getString("title"),
                    channelId = obj.optString("channelId", ""),
                    channelName = obj.optString("channelName", ""),
                    thumbnailUrl = obj.getString("thumbnailUrl"),
                    publishedAt = obj.optString("publishedAt", ""),
                    isStandaloneApproved = obj.optBoolean("isStandaloneApproved", false)
                )
            )
        }
        return list
    }

    fun verifyPin(inputPin: String): Boolean {
        val savedHash = prefs.getString(KEY_PIN_HASH, null) ?: return false
        return sha256(inputPin.trim()) == savedHash
    }

    fun setPin(newPin: String) {
        prefs.edit().putString(KEY_PIN_HASH, sha256(newPin.trim())).apply()
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val KEY_INITIALIZED = "initialized"
        private const val KEY_CHANNELS = "approved_channels"
        private const val KEY_VIDEOS = "approved_videos"
        private const val KEY_WATCH_LATER = "watch_later_ids"
        private const val KEY_HISTORY = "watch_history"
        private const val KEY_PIN_HASH = "parent_pin_hash"
    }
}
