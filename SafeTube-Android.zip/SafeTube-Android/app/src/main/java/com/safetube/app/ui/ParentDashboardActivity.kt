package com.safetube.app.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.safetube.app.R
import com.safetube.app.data.ApprovalStore
import com.safetube.app.data.YouTubeFeedFetcher
import com.safetube.app.databinding.ActivityParentDashboardBinding
import com.safetube.app.databinding.DialogAddChannelBinding
import com.safetube.app.databinding.DialogAddVideoBinding
import com.safetube.app.databinding.DialogPinBinding
import com.safetube.app.model.ApprovedChannel
import com.safetube.app.model.ApprovedVideo

class ParentDashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityParentDashboardBinding
    private lateinit var store: ApprovalStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityParentDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        store = ApprovalStore(this)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.btnAddChannel.setOnClickListener { showAddChannelDialog() }
        binding.btnAddVideo.setOnClickListener { showAddVideoDialog() }
        binding.btnChangePin.setOnClickListener { showChangePinDialog() }

        refreshLists()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun refreshLists() {
        val channels = store.getApprovedChannels()
        binding.lvChannels.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            channels.map { "${it.name} (${it.channelId})" }
        )
        binding.lvChannels.setOnItemClickListener { _, _, position, _ ->
            val target = channels[position]
            AlertDialog.Builder(this)
                .setTitle(R.string.remove_channel_title)
                .setMessage(target.name)
                .setPositiveButton(R.string.remove) { _, _ ->
                    store.removeChannel(target.channelId)
                    refreshLists()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }

        val videos = store.getApprovedVideos()
        binding.lvVideos.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            videos.map { "${it.title} (${it.videoId})" }
        )
        binding.lvVideos.setOnItemClickListener { _, _, position, _ ->
            val target = videos[position]
            AlertDialog.Builder(this)
                .setTitle(R.string.remove_video_title)
                .setMessage(target.title)
                .setPositiveButton(R.string.remove) { _, _ ->
                    store.removeVideo(target.videoId)
                    refreshLists()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    private fun showAddChannelDialog() {
        val dialogBinding = DialogAddChannelBinding.inflate(layoutInflater)
        AlertDialog.Builder(this)
            .setTitle(R.string.add_approved_channel)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.add) { _, _ ->
                val rawInput = dialogBinding.etChannelInput.text?.toString().orEmpty()
                val name = dialogBinding.etChannelName.text?.toString()?.trim().orEmpty()
                val channelId = YouTubeFeedFetcher.extractChannelId(rawInput)
                if (channelId == null) {
                    Toast.makeText(this, R.string.invalid_channel_id, Toast.LENGTH_LONG).show()
                } else {
                    store.addChannel(ApprovedChannel(channelId, name.ifEmpty { channelId }))
                    refreshLists()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showAddVideoDialog() {
        val dialogBinding = DialogAddVideoBinding.inflate(layoutInflater)
        AlertDialog.Builder(this)
            .setTitle(R.string.add_approved_video)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.add) { _, _ ->
                val rawUrl = dialogBinding.etVideoUrl.text?.toString().orEmpty()
                val title = dialogBinding.etVideoTitle.text?.toString()?.trim().orEmpty()
                val channelName = dialogBinding.etVideoChannel.text?.toString()?.trim().orEmpty()
                val videoId = YouTubeFeedFetcher.extractVideoId(rawUrl)
                if (videoId == null) {
                    Toast.makeText(this, R.string.invalid_video_url, Toast.LENGTH_LONG).show()
                } else {
                    store.addVideo(
                        ApprovedVideo(
                            videoId = videoId,
                            title = title.ifEmpty { "Approved Video ($videoId)" },
                            channelName = channelName.ifEmpty { "Parent Approved" }
                        )
                    )
                    refreshLists()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showChangePinDialog() {
        val dialogBinding = DialogPinBinding.inflate(layoutInflater)
        AlertDialog.Builder(this)
            .setTitle(R.string.change_pin)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.save) { _, _ ->
                val newPin = dialogBinding.etPin.text?.toString()?.trim().orEmpty()
                if (newPin.length < 4) {
                    Toast.makeText(this, R.string.pin_too_short, Toast.LENGTH_SHORT).show()
                } else {
                    store.setPin(newPin)
                    Toast.makeText(this, R.string.pin_updated, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
